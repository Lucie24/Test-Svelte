<script>
	let count = 0;

	function incrementCount() {
		count += 1;
		console.log("Vous avez cliqu� sur un lien situ� sur le header ! Votre nombre de clics sur des liens du header est maintenant de : " + count + " clic(s)");
	}
</script>

<header>
	<div class="nav-container">
				<nav class="nav-list">
					<ul>
						<li class="nav-item">
							<a href="#1" class="nav-item-link" on:click={incrementCount}>lien 1</a>
						</li>
						<li class="nav-item">
							<a href="#2" class="nav-item-link" on:click={incrementCount}>lien 2</a>
						</li>
						<li class="nav-item">
							<a href="#3" class="nav-item-link" on:click={incrementCount}>lien 3</a>
						</li>
					</ul>
				</nav>
			</div>
</header>

<style>
	/*common content*/
header{
  border-bottom: 3px solid lightgrey;
  background-color: #fff;
}
	
ul{
  list-style: inline;
}

li{
  list-style: none;
}

a{ 
  text-decoration: none;
  transition: all .5s;
}

a:hover{ 
  text-decoration: underline; 
}
	
/*end common content*/

/*header*/

/*nav*/

.nav-container{
  height: 3rem;
  margin-top: 1rem;
  margin-bottom: 1rem;
  display: flex;
	justify-content: center;
}

.nav-item{
  display: inline-block;
  text-transform: uppercase;
  font-size: 0.8rem;
  margin-top: 1.2rem;
  border-right: 2px solid #4bc1c7;
  padding-left: 1rem;
  padding-right: 1rem;
}

.nav-item-link{
  color: #4bc1c7;
  font-weight: bold;
  text-decoration: none;
}
/*end nav*/
</style>