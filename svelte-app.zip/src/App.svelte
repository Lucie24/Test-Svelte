<script>
	import Header from './Header.svelte';
	import Section1 from './Section1.svelte';
	import Section2 from './Section2.svelte';
	import Footer from './Footer.svelte';
</script>

<main>
	<h1 id="debut">
		Ceci est un site test Svelte
	</h1>
<Header/>
<Section1/>
<Section2/>
</main>
<Footer/>

<style>
main{
  background-color: #f1f1f1;
  padding-top: 1rem;
  padding-bottom: 1rem;
	padding-left: 2rem;
	padding-right: 2rem;
}
h1{
	text-align: center;
}
</style>