<script>
	let src = '/tutorial/image.gif';
	let count = 0;

	function incrementCount() {
		count += 1;
		console.log("Vous avez cliqu� sur un lien situ� sur la section 2 ! Votre nombre de clics sur des liens de la section 2 est maintenant de : " + count + " clic(s)");
	}
	
	function rickroll() {
		alert("Never gonna give you up !");
	}
</script>

<section>
	<h1>Ev�nements</h1>
	<div class="section-event-container">
		<article class="article-event-container">
			<div class="article-event">
				<div>
					<p class="aside-top">Devoirs</p>
					<div class="article-event-text">
						<h2>Rendu S1</h2>
						<p>Exercice pas � pas.</p>
						<div class="article-link-container">
							<a href="#6" class="article-event-link" on:click={incrementCount}>Lire la suite</a>
						</div>
					</div>
				</div>
				<aside class="aside-right">
					<p>25 Sept. 2021</p>
				</aside>
			</div>
			<div class="article-event">
				<div>
					<p class="aside-top">Devoirs</p>
					<div class="article-event-text">
						<h2>Rendu S2</h2>
						<p>Int�gration compl�te d'une page HTML/CSS � partir d'une maquette et d'�l�ments fournis.</p>
						<div class="article-link-container">
							<a href="#7" class="article-event-link" on:click={incrementCount}>Lire la suite</a>
						</div>
					</div>
				</div>
				<aside class="aside-right">
					<p>02 Oct. 2021</p>
				</aside>
			</div>
			<div class="article-event">
				<div>
					<p class="aside-top">Devoirs</p>
					<div class="article-event-text">
						<h2>Rendu S3</h2>
						<p>Exercice pas � pas sur le Responsive Design. <br>Responsive de l'exercice S2 � rendre.</p>
						<div class="article-link-container">
							<a href="#8" class="article-event-link" on:click={incrementCount}>Lire la suite</a>
						</div>
					</div>
				</div>
				<aside class="aside-right">
					<p>09 Oct. 2021</p>
				</aside>
			</div>
			<div class="article-event">
				<div>
					<p class="aside-top">Devoirs</p>
					<div class="article-event-text">
						<h2>Rendu S4</h2>
						<p>One page sur le sujet de votre choix (validit� au pr�alable), version desktop, tablette et mobile</p>
						<div class="article-link-container">
							<a href="#9" class="article-event-link" on:click={incrementCount}>Lire la suite</a>
						</div>
					</div>
				</div>
				<aside class="aside-right">
					<p>18 Oct. 2021</p>
				</aside>
			</div>
		</article>

		<article class="img-event-container">
			<img {src} class="img-event" alt="Rick Astley" on:click={rickroll}>
			<div class="article-event-img">
				<div>
					<p class="aside-top-img">Ciel</p>
					<div class="article-event-text">
						<h2>Ciel de fin de l'UE</h2>
						<p>Pr�sentez-vous 10 minutes avant pour v�rifier que vos cams fonctionnent bien.</p>
						<div class="article-link-container">
							<a href="#9" class="article-event-link" on:click={incrementCount}>Lire la suite</a>
						</div>
					</div>
				</div>
				<aside class="aside-right">
					<p>22 Oct. 2021</p>
				</aside>
			</div>
		</article>
	</div>
</section>

<style>
/*event section*/

.section-event-container{
  display: flex;
}

.article-event-container{
  flex-basis: 40%;
  padding-right: 1rem;
}

.article-event{
  background-color: #fff;
  margin-top: 1rem;
  box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.5);
  display: flex;
}

.aside-top{
  background-color: #b51823;
  color: #fff;
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
  padding-left: 2rem;
  padding-right: 2rem;
  margin-right: 16rem;
}

.article-event-text{
  padding-left: 1rem;
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
}

.article-event-link{
  color: #b51823;
  padding-right: 1rem;
}

.aside-right{
  display: flex;
  text-align: center;
  align-items: center;
  font-size: 1.2rem;
  background-color: #b51823;
  color: #fff;
  padding: 1rem;
  border-top-left-radius: 1rem;
  border-bottom-left-radius: 1rem;
}

.img-event-container{
  flex-basis: 60%;
  margin-right: 2rem;
}

.article-event-img{
  background-color: #fff;
  display: flex;
  box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.5);
}

.aside-top-img{
  background-color: #b51823;
  color: #fff;
  padding-top: 0.25rem;
  padding-bottom: 0.25rem;
  padding-left: 2rem;
  padding-right: 2rem;
  margin-right: 25rem;
}

.img-event{
  margin-top: 1rem;
  max-width: 37rem;
  box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.5);
}
</style>