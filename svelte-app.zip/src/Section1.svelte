<script>
	let count = 0;

	function incrementCount() {
		count += 1;
		console.log("Vous avez cliqu� sur un lien situ� sur la section 1 ! Votre nombre de clics sur des liens de la section 1 est maintenant de : " + count + " clic(s)");
	}
	
	function button() {
		alert("Vous avez cliqu� sur un bouton, bravo !");
	}
</script>

<section>
				<p class="accueil">Accueil<span class="color-slash">/</span><strong>UE234</strong></p>
				<article>
					<h1>UE234 - Int�gration multim�dia niveau 1</h1>
					<div  class="ue234-intro-container">
						<p class="ue234-intro"><i>Bienvenue dans l'UE 234, Int�gration Multim�dia niveau 1.<br>Dans cette UE qui inaugure cette nouvelle ann�e, nous allons revoir toutes les bases de l'int�gration web : HTML et CSS.</i></p>
						<aside class="ue234-aside">
							<p><span class="ue234-big-number">90%</span> <br> <strong>de r�ussite du premier coup</strong></p>
						</aside>
					</div>
				</article>

				<article class="article-ue234-container">
					<div class="first-article">
						<h1 class="first-article-title">Derni�res actualit�s</h1>
						<p class="first-article-text">D�couvrez nos derni�res actualit�s</p>
						<div class="button-container">
							<a href="#4" class="article-button" on:click={button}>Voir toutes les actualit�s</a>
						</div>
					</div>
					<div class="second-article">
						<h1 class="second-article-title">Titre de mon actualit�</h1>
						<p class="article-date">07/09/2021</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas efficitur congue nulla, sit amet porttitor justo dignissim ut. Donec bibendum ultricies tempus.</p>
						<div class="article-link-container">
							<a href="#5" class="article-link" on:click={incrementCount}>Lire le d�tail</a>
						</div>
					</div>
					<div class="third-article">
						<h1 class="second-article-title">Titre de mon actualit�</h1>
						<p class="article-date">07/09/2021</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas efficitur congue nulla, sit amet porttitor justo dignissim ut. Donec bibendum ultricies tempus.</p>
						<div class="article-link-container">
							<a href="#6" class="article-link" on:click={incrementCount}>Lire le d�tail</a>
						</div>
					</div>
				</article>
			</section>

<style>
/*UE234 section*/

.accueil{
  margin-top: 0.5rem;
  margin-bottom: 2rem;
  font-size: 0.8rem;
}

.color-slash{
  color: #4bc1c7;
}

/*UE234 intro*/

.ue234-intro-container{
  margin-top: 1rem;
  display: flex;
}

.ue234-intro{
  flex-basis: 67%;
}

.ue234-aside{
  flex-basis: 33%;
  border-left: 5px solid #4bc1c7;
  padding-left: 1rem;
  padding-top: 1rem;
}

.ue234-big-number{
  color: #4bc1c7;
  font-size: 2rem;
  font-weight: bold;
}

/*end UE234 intro*/

/*UE234 articles*/

.article-ue234-container{
  display: flex;
  margin-top: 2rem;
  margin-bottom: 2rem;
}

.first-article{
  background-color: #4bc1c7;
  flex-basis: 33%;
  text-align: center;
  padding: 2rem;
}

.first-article-title{
  color: #fff;
  text-transform: uppercase;
}

.first-article-text{
  color: #fff;
}

.button-container{
  margin-top: 1.5rem;
}

.article-button{
  background-color: #fff;
  color: #4bc1c7; 
  border: 1px solid #fff;
  padding-top: 0.5rem;
  padding-left: 1rem;
  padding-right: 1rem;
  padding-bottom: 0.5rem;
  margin-top: 1rem;
  margin-bottom: 1rem;
  border-radius: 2rem;
  text-align: center;
  text-decoration: none;
  transition: all .2s;
}

.article-button:hover{
  background-color: #4bc1c7;
  color: #fff;
  border: 2px solid #fff;
}

.second-article, .third-article{
  background-color: #fff;
  flex-basis: 33%;
  padding: 1rem;
  text-align: left;
  border-left: 2px solid #4bc1c7;
}

.second-article-title{
  color: #4bc1c7;
}

.article-date{
  font-size: 0.8rem;
  color: grey;
  margin-bottom: 1rem;
}

.article-link-container{
  display: flex;
  justify-content: flex-end;
}

.article-link{
  color: #4bc1c7;
  text-decoration: none;
}

.article-link:hover{
  color: #4bc1c7;
  text-decoration: underline;
}

/*end UE234 articles*/

/*end UE234 section*/
</style>