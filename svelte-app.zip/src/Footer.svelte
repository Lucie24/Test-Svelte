<script>
	let count = 0;

	function incrementCount() {
		count += 1;
		console.log("Vous avez cliqu� sur un lien situ� sur le footer ! Votre nombre de clics sur des liens du footer est maintenant de : " + count + " clic(s)");
	}
	
	function tel() {
		alert("Uh oh ! on n'appelle pas un num�ro au hasard !");
	}
</script>

<footer>
			<div class="personal-informations">
				<p>DUMAS Lucie</p>
				<p>D�veloppement</p>
				<p>Limoges / France</p>
				<a href="#numero_osef" title="Ouvrir l'application mobile" class="personal-informations-phone" on:click={incrementCount} on:click={tel}>05 55 45 72 00</a>
			</div>
			<a href="#debut" class="button-top" on:click={incrementCount}>Top</a>
			<div class="legal-notice">
				<a href="#10" class="legal-notice-text" on:click={incrementCount}>Mentions l�gales</a>
				<a href="#11" class="legal-notice-text" on:click={incrementCount}>Politique de confidentialit�</a>
			</div>
		</footer>

<style>
/*footer*/

.personal-informations{
  color: #000;
  padding-top: 1rem;
  padding-left: 14rem;
  padding-bottom: 1rem;
}

.personal-informations-phone{
  color: #4bc1c7;
  transition: all .2s;
}

.personal-informations-phone:hover{
  color: #000;
}

.button-top{
  color: #fff;
  background-color: #b51823;
  padding: 1rem;
  border-radius: 0.5rem;
  position: fixed;    
  bottom: 1.5rem; 
	margin-left: 2rem;
  transition: all .2s;
}

.button-top:hover{
color: #b51823;
background-color: #fff;
border: 2px solid #b51823;
}

.legal-notice{
  color: #fff;
  background-color: #4bc1c7;
  display: flex;
  justify-content: center;
}

.legal-notice-text{
  text-transform: uppercase;
  padding-left: 1rem;
  margin: 1rem;
  font-size: 0.8rem;
  color: #fff;
}

/*end footer*/
</style>